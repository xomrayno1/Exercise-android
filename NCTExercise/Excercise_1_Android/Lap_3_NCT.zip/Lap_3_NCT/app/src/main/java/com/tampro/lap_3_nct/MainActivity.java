package com.tampro.lap_3_nct;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btnTang,btnGiam,btnOpen;
    TextView txtNumber;
    int number  ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnTang = (Button) findViewById(R.id.btn_tang);
        btnGiam = (Button) findViewById(R.id.btn_giam);
        btnOpen = (Button) findViewById(R.id.btn_open);
        txtNumber= (TextView) findViewById(R.id.txtSo);

        btnTang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 number = Integer.parseInt(txtNumber.getText().toString());
                txtNumber.setText(String.valueOf(number+1));
            }
        });
        btnGiam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 number = Integer.parseInt(txtNumber.getText().toString());
                txtNumber.setText(String.valueOf(number-1));
            }
        });
        btnOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,AgeActivity.class);
                startActivity(intent);

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();

        return true;
    }
}
