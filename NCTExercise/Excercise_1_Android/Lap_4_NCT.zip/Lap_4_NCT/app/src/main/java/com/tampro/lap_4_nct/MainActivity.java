package com.tampro.lap_4_nct;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText edtName,edtYear;
    Button btnTinh;
    TextView txtAlert;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtAlert = (TextView) findViewById(R.id.txtAlert);
        edtName = (EditText) findViewById(R.id.edtName);
        edtYear = (EditText) findViewById(R.id.edtYear);
        btnTinh = (Button) findViewById(R.id.btnTinhtuoi);
        btnTinh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int Age = Calendar.getInstance().get(Calendar.YEAR)-Integer.parseInt(edtYear.getText().toString());
                txtAlert.setText("Ban :"+edtName.getText()+ " "+Age + " Tuoi");
        }
        });
    }
}
