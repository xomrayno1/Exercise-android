package com.tampro.lap_7_nct;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnStart;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnStart = (Button) findViewById(R.id.btnStart);
        textView = (TextView) findViewById(R.id.textView);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new CountDownTimer(20000,1000){

                    @Override
                    public void onTick(long millisUntilFinished) {
                        textView.setText(""+ millisUntilFinished/1000);
                    }

                    @Override
                    public void onFinish() {
                        Toast.makeText(MainActivity.this, "Kết Thúc", Toast.LENGTH_SHORT).show();
                    }
                }.start();
            }
        });

    }
}
