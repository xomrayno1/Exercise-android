package com.tampro.excercise_3_1_android;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    ToggleButton togggle ;
    Switch sw;
    CheckBox gdNam,gdNu;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Mapping();
        togggle.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                boolean Check =  togggle.isChecked();
                if(Check){
                    Toast.makeText(MainActivity.this,"Không Độc Thân - onClick",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this," Độc Thân - onClick",Toast.LENGTH_SHORT).show();
                }
            }
        });
        togggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Toast.makeText(MainActivity.this,"Không Độc Thân - CheckChange",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this," Độc Thân - CheckChange",Toast.LENGTH_SHORT).show();
                }
            }
        });
        sw.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                boolean Check =  sw.isChecked();
                if(Check){
                    Toast.makeText(MainActivity.this,"Bật- onClick",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this," Tắt - onClick",Toast.LENGTH_SHORT).show();
                }
            }
        });
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Toast.makeText(MainActivity.this,"Bật- CheckChange",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this," Tắt - CheckChange",Toast.LENGTH_SHORT).show();
                }
            }
        });
        gdNam.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                boolean Check =  gdNam.isChecked();
                if(Check){
                    Toast.makeText(MainActivity.this,"Nam- onClick",Toast.LENGTH_SHORT).show();
                }
            }
        });
        gdNu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                boolean Check =  gdNu.isChecked();
                if(Check){
                    Toast.makeText(MainActivity.this,"Nữ- onClick",Toast.LENGTH_SHORT).show();
                }
            }
        });
        gdNam.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Toast.makeText(MainActivity.this,"Chọn Nam",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this," Không Chọn Nam",Toast.LENGTH_SHORT).show();
                }
            }
        });
        gdNu.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Toast.makeText(MainActivity.this,"Chọn Nữ",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this," Không Chọn Nữ",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }


    public void Mapping(){
        togggle  = (ToggleButton) findViewById(R.id.single);
        sw = (Switch) findViewById(R.id.switch1);
        gdNam = (CheckBox) findViewById(R.id.gdNam);
        gdNu = (CheckBox) findViewById(R.id.gdNu);

    }


}
