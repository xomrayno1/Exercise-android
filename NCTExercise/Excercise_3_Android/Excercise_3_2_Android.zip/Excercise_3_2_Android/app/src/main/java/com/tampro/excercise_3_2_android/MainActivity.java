package com.tampro.excercise_3_2_android;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    Button btnCancel, btnRegister;
    EditText edtPassword, edtName,edtBirthday,edtEmail;
    ToggleButton tgSingle;
    CheckBox gdNam,gdNu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Mapping();
        btnCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Clear();
            }
        });
        gdNam.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(gdNam.isChecked()){
                    gdNu.setChecked(false);
                }

            }
        });
        gdNu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(gdNu.isChecked()){
                    gdNam.setChecked(false);
                }
            }
        });
        tgSingle.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                StringBuilder builder = new StringBuilder();
                builder.append("Name  :" +edtName.getText().toString() + "  Birthday : "+edtBirthday.getText().toString()
                        + " Email : "+edtEmail.getText().toString()+" Password : "+edtPassword.getText().toString()+ "  ");
                builder.append("Gender : "+ CheckGender() + "Single  : "+CheckSingle());
                AlertDialog.Builder  alert= new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Show Thông Tin");
                alert.setMessage(builder.toString());
                alert.show();



            }
        });
    }

    public String CheckGender(){
        gdNam = (CheckBox) findViewById(R.id.gdNam);
        gdNu = (CheckBox) findViewById(R.id.gdNu);
        if(gdNam.isChecked()){
            return "Nam";
        }
        return "Nũ" ;
    }
    public String CheckSingle(){
        tgSingle = (ToggleButton) findViewById(R.id.tgSingle);
        if(tgSingle.isChecked()){return " Không Độc Thân";}
        return "Độc Thân";
    }
    public void Clear(){
        edtPassword.setText("");
        edtName.setText("");
        edtBirthday.setText("");
        edtEmail.setText("");
        gdNam.setChecked(false);
        gdNu.setChecked(false);
        tgSingle.setChecked(false);
    }

    public void Mapping(){
        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        edtName = (EditText) findViewById(R.id.edtName);
        edtBirthday = (EditText) findViewById(R.id.edtBirthday);
        edtEmail = (EditText) findViewById(R.id.edtEmail);
        tgSingle = (ToggleButton) findViewById(R.id.tgSingle);
        gdNam = (CheckBox) findViewById(R.id.gdNam);
        gdNu = (CheckBox) findViewById(R.id.gdNu);
    }
}
