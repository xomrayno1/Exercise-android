package com.tampro.newapp;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class CustomListAdapter extends ArrayAdapter<User> {

    private Context context;
    private ArrayList<User> list ;
    private int layoutResource;

    public CustomListAdapter(Context context , int resource,ArrayList<User> list){
        super(context,resource,list);
        this.context = context;
        this.list = list;
        this.layoutResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        convertView = inflater.inflate(layoutResource,null);
        View rowView = inflater.inflate(R.layout.activity_main,null,true);




        TextView textView =(TextView) convertView.findViewById(R.id.txtViewName);
        textView.setText(list.get(position).getName());

        TextView textView1 =(TextView) convertView.findViewById(R.id.txtViewPhone);
        textView1.setText(list.get(position).getSdt());

        ImageView img = (ImageView) convertView.findViewById(R.id.img);
        img.setImageResource(this.list.get(position).getImg());

        return  convertView;
    }
}
