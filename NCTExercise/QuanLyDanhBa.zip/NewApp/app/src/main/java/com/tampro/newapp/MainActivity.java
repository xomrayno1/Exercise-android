package com.tampro.newapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText txtName,txtNumberphone;
    ListView listView ;
    Button btnAdd;
    RadioButton radioButton;
    RadioGroup rdGender;

    private Activity context;
    CustomListAdapter customListAdapter;
    ArrayList<User> arrList = new ArrayList<User>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Mapping();
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int  gender =  0 ;
                switch (rdGender.getCheckedRadioButtonId()){
                    case R.id.nam:
                        gender = R.mipmap.male;
                        break;
                    case R.id.nu :
                        gender = R.mipmap.female;
                        break;
                }
                if(txtName.getText().length() == 0  || txtName.getText().length() == 0  || gender == 0){
                    Toast.makeText(MainActivity.this,"Điền Đầy Đủ",Toast.LENGTH_SHORT).show();
                }else{

                    arrList.add(new User(txtName.getText().toString(),txtNumberphone.getText().toString(), gender));
                    customListAdapter  = new CustomListAdapter(MainActivity.this,R.layout.row_item_contact,arrList);

                    listView.setAdapter(customListAdapter);
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Toast.makeText(MainActivity.this,arrList.get(position).toString(),Toast.LENGTH_SHORT).show();
                        }
                    });
                    Clear();
                }

            }
        });


    }

    public void Clear(){
        txtName.setText("");
        txtNumberphone.setText("");
        rdGender.clearCheck();
    }


    public void Mapping(){
        txtName = (EditText) this.findViewById(R.id.txtName);
        txtNumberphone = (EditText) this.findViewById(R.id.txtNumberphone);
        listView = (ListView) this.findViewById(R.id.lvDanhBa);
        btnAdd = (Button) this.findViewById(R.id.btnAdd);
        rdGender = (RadioGroup) this.findViewById(R.id.rdGender);

    }


}
