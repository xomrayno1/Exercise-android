package com.tampro.newapp;

public class User {
    private String name;
    private String sdt;
    private int img;

     public User(){

     }
     public User(String name,String sdt,int img){
         this.name = name;
         this.sdt = sdt;
         this.img = img;
     }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
